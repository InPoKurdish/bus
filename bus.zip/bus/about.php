<!DOCTYPE html>
<html lang="ckb">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
                *{
            font-family: calibri !important;
        }
        body {
            margin: 0;
            padding: 0;
            overflow: hidden;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #ecf0f1;
            direction: rtl;
        }
        .back-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #3498db;
            color: #fff;
            text-decoration: none;
            font-size: 16px;
            border-radius: 8px;
            transition: background-color 0.3s ease;
            margin: 20px;
        }

        .back-button:hover {
            background-color: #2980b9;
        }
        p, h2, a {
            font-size: xx-large;
            direction: rtl;
        }
    </style>
</head>
<body>
<a href="index.php" class="back-button">Back</a>
<div>
<h2>دەربارەی ئێمە</h2>
<p>ئەم سیستەمە دروستکراوە بۆ ئاسانکاری لە ژیانی بەکارهێنەرانی پاس.
</p>
<p>
لەئەگەری ونبوونی هەر کاڵایەك یاخود کەلوپەلێك دەتوانن ئاگادارمان بکەنەوە لە ڕێگەی:
</p>
<a href="mailto:20728@stirlingschools.co.uk">20728@stirlingschools.co.uk</a>
</div>
</html>